LANTERNFALL HERO STYLE PACK (for GPT)

style-reference-sheet.png  Wren and Tobin at camp and in their fight stance, 3x. Match this look.
wren/poses, tobin/poses    The original full-body sprites exactly as GPT made them (224x192, anchor 96,132).
*/palette.png              Each hero's 40-colour palette.
*/animation-previews/*.gif How the game animates the poses. The bow string, arrows, sound waves,
                           the bat, sword swooshes and block sparks are added in code, so never draw them.
art-pipeline.md            The full spec: size, anchor, colour limit, pose sets per class, review checklist.

Target style: Wren's chunkier look. Heavy dark outlines inside the figure as well as around it, and broad,
simple shapes. Tobin is slightly smoother; lean toward Wren.
